#include "mysolution.h"
#include <limits>
#include <random>
#include <omp.h>
#include <immintrin.h>
#include <queue>      // 瑙ｅ喅 priority_queue 鏈畾涔?#include <functional> // 瑙ｅ喅 greater<T> 鏈畾涔?#include <utility>    // 瑙ｅ喅 pair 鏈畾涔?
// --- 甯搁噺閰嶇疆 (缃戞牸鎼滅储浼樺寲) ---
static const int M = 40;
static const int EF_CONSTRUCTION = 300;
static const int EF_SEARCH = 200;
static const float ML = 1.0f / log(2.0f); // ~1.44
static const float GAMMA = 1.0f;          // 鐢ㄤ簬 RobustPrune

// --- 绾跨▼灞€閮ㄥ瓨鍌ㄤ紭鍖?(Optimization 2) ---
struct VisitedBuffer
{
    vector<int> visited_tags;
    int current_tag;

    VisitedBuffer() : current_tag(0) {}

    void prepare(int num_nodes)
    {
        if (visited_tags.size() < (size_t)num_nodes)
        {
            visited_tags.resize(num_nodes, 0);
            current_tag = 0;
        }
        current_tag++;
        if (current_tag == 0)
        { // 婧㈠嚭閲嶇疆
            fill(visited_tags.begin(), visited_tags.end(), 0);
            current_tag = 1;
        }
    }

    bool is_visited(int id) const
    {
        return visited_tags[id] == current_tag;
    }

    void mark(int id)
    {
        visited_tags[id] = current_tag;
    }
};

static thread_local VisitedBuffer tls_visited;
static thread_local vector<unsigned char> tls_quant_query_buf;    // 閬垮厤棰戠箒鐢宠鍐呭瓨
static thread_local vector<pair<float, int>> tls_candidate_queue; // [鎬ц兘浼樺寲] 澶嶇敤鍊欓€夐槦鍒楀唴瀛?
// --- 杈呭姪缁撴瀯锛氬浐瀹氬ぇ灏忕殑鍊欓€夐泦 (Optimization 5) ---
// 鏇夸唬 priority_queue 浠ュ噺灏戝爢鎿嶄綔寮€閿€
struct Candidate
{
    float dist;
    int id;

    bool operator<(const Candidate &other) const
    {
        return dist < other.dist;
    }
    bool operator>(const Candidate &other) const
    {
        return dist > other.dist;
    }
};

// --- 璺濈璁＄畻瀹炵幇 ---

// 浼樺寲1: AVX2 SIMD 娴偣璺濈
inline float Solution::dist_l2_float_avx(const float *a, const float *b, int d) const
{
#if defined(__AVX2__)
    __m256 sum = _mm256_setzero_ps();
    const float *pA = a;
    const float *pB = b;
    int i = 0;
    for (; i + 8 <= d; i += 8)
    {
        __m256 va = _mm256_loadu_ps(pA + i);
        __m256 vb = _mm256_loadu_ps(pB + i);
        __m256 diff = _mm256_sub_ps(va, vb);
        sum = _mm256_fmadd_ps(diff, diff, sum);
    }
    float res[8];
    _mm256_storeu_ps(res, sum);
    float total = res[0] + res[1] + res[2] + res[3] + res[4] + res[5] + res[6] + res[7];
    for (; i < d; ++i)
    {
        float diff = pA[i] - pB[i];
        total += diff * diff;
    }
    return total;
#else
    float total = 0;
    for (int i = 0; i < d; ++i)
    {
        float diff = a[i] - b[i];
        total += diff * diff;
    }
    return total;
#endif
}

// 鏂规A: 閲忓寲璺濈璁＄畻 (Layer 0 涓撶敤)
inline float Solution::dist_l2_quant(int id_a, const unsigned char *b_quant, int d) const
{
    const unsigned char *p_quant = &data_quant[(long long)id_a * d];
    long long raw_dist_sq = 0;

// 鎸囧崡瑕佹眰鐨勫疄鐜版柟寮忥紝鍒╃敤Simd Reduction
// 娉ㄦ剰锛氳繖閲岀紪璇戝櫒浼氳嚜鍔ㄥ悜閲忓寲
#pragma omp simd reduction(+ : raw_dist_sq)
    for (int i = 0; i < d; ++i)
    {
        int diff = (int)p_quant[i] - (int)b_quant[i];
        raw_dist_sq += diff * diff;
    }
    return (float)raw_dist_sq;
}

// --- 閲忓寲閫昏緫 ---

void Solution::init_quantization()
{
    if (num_vectors == 0)
        return;

    // 1. 璁＄畻鍏ㄥ眬鑼冨洿
    float min_val = std::numeric_limits<float>::max();
    float max_val = std::numeric_limits<float>::lowest();

    // 閲囨牱閮ㄥ垎鍚戦噺浠ュ姞閫熻寖鍥磋绠?(鍏ㄩ儴閬嶅巻涔熷緢蹇紝杩欓噷涓虹ǔ濡ュ叏閬嶅巻)
    for (const auto &v : data_flat)
    {
        if (v < min_val)
            min_val = v;
        if (v > max_val)
            max_val = v;
    }

    global_min = min_val;
    if (max_val - min_val < 1e-6f)
    {
        global_scale_inv = 0;
        use_quantization = false;
    }
    else
    {
        global_scale_inv = 255.0f / (max_val - min_val);
        use_quantization = true;
    }

    // 2. 閲忓寲鎵€鏈夊熀搴撳悜閲?    long long total_elements = (long long)num_vectors * dimension;
    data_quant.resize(total_elements);

#pragma omp parallel for
    for (int i = 0; i < num_vectors; ++i)
    {
        quantize_vec(&data_flat[i * dimension], &data_quant[(long long)i * dimension]);
    }
}

inline void Solution::quantize_vec(const float *src, unsigned char *dst) const
{
    if (!use_quantization)
        return;
    for (int i = 0; i < dimension; ++i)
    {
        int q = static_cast<int>((src[i] - global_min) * global_scale_inv + 0.5f);
        if (q < 0)
            q = 0;
        if (q > 255)
            q = 255;
        dst[i] = (unsigned char)q;
    }
}

// --- 鎼滅储灞傞€昏緫 ---

// 鏋勫缓闃舵浣跨敤鐨勬悳绱?(绮剧‘璺濈锛屾搷浣滃姩鎬佸浘)
void Solution::search_layer_build(const float *query, vector<int> &candidates,
                                  const vector<int> &ep, int ef, int lc) const
{

    Candidate top_candidates[512]; // Fixed size buffer
    int sz = 0;

    tls_visited.prepare(num_vectors);

    // 浼樺厛闃熷垪閫昏緫 (浣跨敤std::priority_queue浼氭參锛岃繖閲岀敤绠€鍗曠殑鎺掑簭鏁扮粍鎴栧爢)
    // 涓轰繚鎸佷唬鐮佺畝娲佷笖閬靛惊鎸囧崡锛屼娇鐢ㄦ爣鍑嗙殑鏈€灏?鏈€澶у爢閫昏緫
    // 涓轰簡鏋佽嚧鎬ц兘锛岃繖閲屾墜鍔ㄧ淮鎶や袱涓泦鍚?
    // C: 寰呮帰绱㈤泦鍚?(min-heap by distance)
    // W: 缁撴灉闆嗗悎 (max-heap by distance, size <= ef)

    priority_queue<pair<float, int>, vector<pair<float, int>>, greater<pair<float, int>>> C;
    priority_queue<pair<float, int>> W;

    // 鍒濆鍖栧叆鍙ｇ偣
    for (int pid : ep)
    {
        if (!tls_visited.is_visited(pid))
        {
            tls_visited.mark(pid);
            float dist = dist_l2_float_avx(query, &data_flat[pid * dimension], dimension);
            C.push({dist, pid});
            W.push({dist, pid});
            if (W.size() > ef)
                W.pop();
        }
    }

    while (!C.empty())
    {
        auto curr = C.top();
        C.pop();
        float dist_c = curr.first;
        int id_c = curr.second;

        if (dist_c > W.top().first)
            break; // 鍓灊

        // 閬嶅巻閭诲眳
        const vector<int> &neighbors = nodes[id_c].neighbors[lc];

        // 棰勫彇浼樺寲 (Optimization 6)
        for (size_t i = 0; i < neighbors.size(); ++i)
        {
            int nid = neighbors[i];
            if (tls_visited.is_visited(nid))
                continue;
            tls_visited.mark(nid);

            // Prefetch next
            if (i + 1 < neighbors.size())
            {
                _mm_prefetch((const char *)&data_flat[neighbors[i + 1] * dimension], _MM_HINT_T0);
            }

            float d = dist_l2_float_avx(query, &data_flat[nid * dimension], dimension);

            if (W.size() < ef || d < W.top().first)
            {
                W.push({d, nid});
                C.push({d, nid});
                if (W.size() > ef)
                    W.pop();
            }
        }
    }

    // 鏀堕泦缁撴灉
    candidates.clear();
    while (!W.empty())
    {
        candidates.push_back(W.top().second);
        W.pop();
    }
    // W pop鍑烘潵鏄檷搴忥紝闇€瑕佸弽杞垚鍗囧簭浠ヤ究鍚庣画澶勭悊 (铏界劧Heuristic閲屼細閲嶆帓锛屼絾淇濇寔鏈夊簭濂?
    // 浣咹euristic閫氬父鍙渶瑕侀泦鍚堛€傝繖閲屼笉鐢ㄥ弽杞€?}

// 鏈€缁堟煡璇㈤樁娈典娇鐢ㄧ殑鎼滅储 (Layer 0浣跨敤閲忓寲 + 鎵佸钩鍥?
// [淇鐗堟湰] 浣跨敤鏍囧噯HNSW鍙屽爢閫昏緫锛岄伩鍏嶆悳绱㈡彁鍓嶇粓姝?void Solution::search_layer_query(const float *query, const unsigned char *query_quant,
                                  vector<int> &candidates, const vector<int> &ep,
                                  int ef, int lc) const
{

    tls_visited.prepare(num_vectors);

    // 鏍囧噯HNSW鍙屽爢绛栫暐锛?    // C (candidates): 鏈€灏忓爢锛岃窛绂昏繎鐨勫厛鍑洪槦 - 鐢ㄤ簬鎺㈢储
    // W (results): 鏈€澶у爢锛岃窛绂昏繙鐨勫湪鍫嗛《 - 鐢ㄤ簬淇濈暀鏈€浼樼粨鏋?    priority_queue<pair<float, int>, vector<pair<float, int>>, greater<pair<float, int>>> C; // min-heap
    priority_queue<pair<float, int>> W;                                                      // max-heap (榛樿)

    // 鍒濆鍖栧叆鍙ｇ偣
    for (int pid : ep)
    {
        if (!tls_visited.is_visited(pid))
        {
            tls_visited.mark(pid);
            float d;
            // [涓存椂] 绂佺敤閲忓寲浠ラ獙璇佹诞鐐硅窛绂绘纭€?            // if (lc == 0 && use_quantization && query_quant) {
            //     d = dist_l2_quant(pid, query_quant, dimension);
            // } else {
            d = dist_l2_float_avx(query, &data_flat[pid * dimension], dimension);
            // }
            C.push({d, pid});
            W.push({d, pid});
            if ((int)W.size() > ef)
                W.pop();
        }
    }

    // 涓绘悳绱㈠惊鐜?    while (!C.empty())
    {
        auto curr = C.top();
        C.pop();

        float dist_c = curr.first;
        int nid = curr.second;

        // [鍏抽敭淇] 鍙湁褰撳€欓€夐泦涓渶杩戠殑鐐归兘姣旂粨鏋滈泦鏈€杩滅殑鐐硅繙鏃舵墠鍋滄
        // 纭繚 W 鑷冲皯鏈変竴涓厓绱犳墠姣旇緝
        if (!W.empty() && dist_c > W.top().first)
        {
            break;
        }

        // 鑾峰彇閭诲眳鎸囬拡
        const int *neighbors_ptr;
        int neighbors_count;

        if (lc == 0)
        {
            // Layer 0: 浠庢墎骞虫暟缁勮鍙?(Optimization 4)
            size_t offset = final_graph_offsets[nid];
            neighbors_count = final_graph_flat[offset];
            neighbors_ptr = &final_graph_flat[offset + 1];
        }
        else
        {
            // High Layer: 浠庤妭鐐瑰璞¤鍙?            const auto &vec = nodes[nid].neighbors[lc];
            neighbors_ptr = vec.data();
            neighbors_count = (int)vec.size();
        }

        for (int i = 0; i < neighbors_count; ++i)
        {
            int neighbor_id = neighbors_ptr[i];
            if (tls_visited.is_visited(neighbor_id))
                continue;
            tls_visited.mark(neighbor_id);

            // Prefetch锛堜繚鐣欎紭鍖栵級
            if (lc == 0 && i + 2 < neighbors_count)
            {
                _mm_prefetch((const char *)&data_flat[neighbors_ptr[i + 2] * dimension], _MM_HINT_T0);
            }

            float d;
            // [涓存椂] 鍏ㄩ儴浣跨敤娴偣璺濈
            // if (lc == 0 && use_quantization && query_quant) {
            //     d = dist_l2_quant(neighbor_id, query_quant, dimension);
            // } else {
            d = dist_l2_float_avx(query, &data_flat[neighbor_id * dimension], dimension);
            // }

            // [鍏抽敭淇] 鍒ゆ柇鏉′欢锛氱粨鏋滈泦鏈弧 鎴?璺濈鏇磋繎
            if ((int)W.size() < ef || d < W.top().first)
            {
                C.push({d, neighbor_id});
                W.push({d, neighbor_id});
                if ((int)W.size() > ef)
                    W.pop();
            }
        }
    }

    // 鏀堕泦缁撴灉
    candidates.clear();
    candidates.reserve(W.size());
    while (!W.empty())
    {
        candidates.push_back(W.top().second);
        W.pop();
    }
    // W pop鍑烘潵鏄檷搴忥紝浣嗚繖閲屼笉闇€瑕佸弽杞紙鍚庣画澶勭悊浼氶噸鎺掞級
}

// --- 閫夐偦灞呯瓥鐣?(RobustPrune) ---
void Solution::get_neighbors_heuristic(vector<int> &result, const vector<int> &candidates, int k) const
{
    if (candidates.size() <= (size_t)k)
    {
        result = candidates;
        return;
    }

    // 1. 鎸夎窛绂绘帓搴忓€欓€夐泦
    vector<pair<float, int>> temp;
    temp.reserve(candidates.size());
    // 娉ㄦ剰锛氳繖閲岄渶瑕佺簿纭窛绂伙紝鍥犱负杩欏彂鐢熷湪鏋勫缓闃舵
    // 涓攃andidates閲岀殑鐐硅窛绂籷uery鐨勮窛绂婚渶瑕侀噸鏂拌绠楁垨浼犻€掞紝涓虹畝鍗曡捣瑙侊紝杩欓噷鍋囪base鏄綋鍓嶆彃鍏ヨ妭鐐?    // 浣咹NSW鏋勫缓涓紝heuristic鏄拡瀵?query (鍗虫柊鎻掑叆鐐? 鍜?candidates 涔嬮棿鐨勫叧绯?    // 鐢变簬鎴戜滑娌℃湁淇濆瓨candidates鐨勮窛绂伙紝杩欓噷绠€鍖栧鐞嗭細
    // 鏍囧噯瀹炵幇涓紝get_neighbors_heuristic 闇€瑕佽绠?candidate 涔嬮棿鐨勮窛绂绘潵淇濊瘉澶氭牱鎬?    // 杩欓噷浼犲叆鐨?candidates 搴旇鏄凡缁忔寜璺濈 query 鎺掑ソ搴忕殑锛屾垨鑰呮垜浠湪澶栭儴鎺掑簭

    // 鐢变簬鎺ュ彛闄愬埗锛屾垜浠湪杩欓噷涓嶉噸鏂拌绠?query 鍒?candidate 鐨勮窛绂伙紝
    // 鑰屾槸鍋囪璋冪敤鑰呭凡缁忓鐞嗗ソ锛屾垨鑰呮垜浠畝鍖栦负鍙仛澶氭牱鎬т慨鍓?    // *淇*: 涓轰簡淇濊瘉鍙洖鐜囷紝蹇呴』瀹炵幇 RobustPrune

    // 杩欓噷鎴戜滑瀹為檯涓婇渶瑕佷紶鍏?query 鐨勫潗鏍囨潵璁＄畻璺濈銆?    // 浣嗕负浜嗕笉鏀瑰彉澶绛惧悕锛屾垜浠亣璁?candidates 宸茬粡鍖呭惈浜嗘渶杩戠殑閭诲眳銆?    // 鍦?build 杩囩▼涓紝select_neighbors 姝ラ浼犲叆鐨?candidates 纭疄鏄渶杩戦偦鎼滅储鐨勭粨鏋溿€?
    result.clear();
    // 鍋囪 candidates 宸茬粡鎸夎窛绂?query 鍗囧簭鎺掑垪 (search_layer_build 杈撳嚭閫氬父涓嶆槸涓ユ牸鏈夊簭锛岄渶瑕佹敞鎰?
    // 浣嗗湪 build 鐨?loop 涓紝鎴戜滑閫氬父浼氬 candidates 杩涜閲嶆帓銆?
    // 杩欓噷鍋氭渶绠€鍗曠殑鎴柇? 涓嶏紝鎸囧崡寮鸿皟鍙洖鐜囥€?    // 鎴戜滑闇€瑕侀噸鏋勯€昏緫锛氬湪build涓紝鎴戜滑鎵嬪姩瀵筩andidates鎺掑簭锛岀劧鍚庡仛RobustPrune

    // 杩欓噷鐨勫疄鐜版槸涓€涓畝鍖栫殑 RobustPrune锛屼笉閲嶆柊璁＄畻璺濈锛屼粎渚濊禆杈撳叆椤哄簭
    // 杩欏湪 candidates 鏄?top-k 缁撴灉鏃舵湁鏁堛€?    // 涓轰簡鏇翠弗璋紝鎴戜滑鍦?build 鍑芥暟鍐呴儴澶勭悊鎺掑簭銆?    for (size_t i = 0; i < candidates.size() && result.size() < (size_t)k; ++i)
    {
        int curr_id = candidates[i];
        bool good = true;

        // 妫€鏌ヤ笌宸查€夎妭鐐圭殑璺濈 (澶氭牱鎬?
        for (int exist_id : result)
        {
            float dist_curr_exist = dist_l2_float_avx(
                &data_flat[curr_id * dimension],
                &data_flat[exist_id * dimension],
                dimension);

            // 涓嬮潰鐨勮窛绂绘槸浠庡閮ㄤ紶鍏ョ殑鍚楋紵涓嶃€?            // 杩欓噷鐨?GAMMA 鍒ゅ畾閫氬父闇€瑕佺煡閬?curr 鍒?query 鐨勮窛绂汇€?            // 鐢变簬缂轰箯 query 淇℃伅锛屾垜浠€€鍖栦负鍙€夋渶杩戠殑 K 涓紙涓嶄娇鐢?Gamma 鍓灊锛夛紝
            // 鎴栬€呰繖閮ㄥ垎閫昏緫鍦?build 涓诲惊鐜腑瀹炵幇鏇村ソ銆?
            // *鍐崇瓥*: 涓轰簡浠ｇ爜缁撴瀯娓呮櫚锛屾垜浠湪 build 涓诲惊鐜腑鍐呰仈 RobustPrune 閫昏緫锛?            // 杩欓噷鐨勫嚱鏁颁粎浣滅畝鍗曠殑 copy銆?        }
        result.push_back(curr_id);
    }
}

// 杈呭姪锛氱敓鎴愰殢鏈哄眰绾?int Solution::get_random_level()
{
    static thread_local std::mt19937 rng(12345 + omp_get_thread_num());
    static thread_local std::uniform_real_distribution<float> dist(0.0, 1.0);
    float r = dist(rng);
    return (int)(-log(r) * ML);
}

// --- 涓绘瀯寤烘祦绋?---
void Solution::build(int d, const vector<float> &base)
{
    dimension = d;
    num_vectors = base.size() / d;
    data_flat = base;

    // 鍙傛暟鍒濆鍖?    M_max = M;
    M_max0 = M * 2;
    max_level = 0;
    enter_point = 0;

    // 鍒濆鍖栬妭鐐?    nodes.resize(num_vectors);

    // 閿?(姣忎釜鑺傜偣涓€鎶婇攣)
    vector<omp_lock_t> node_locks(num_vectors);
    for (int i = 0; i < num_vectors; ++i)
        omp_init_lock(&node_locks[i]);

    // 绗竴涓偣
    int level0 = get_random_level();
    nodes[0].neighbors.resize(level0 + 1);
    max_level = level0;
    enter_point = 0;

// 骞惰鏋勫缓
#pragma omp parallel
    {
        // 绾跨▼灞€閮ㄩ殢鏈烘暟鐢熸垚鍣ㄥ湪 get_random_level 涓鐞?        // 璁块棶缂撳瓨
        tls_visited.prepare(num_vectors);

#pragma omp for schedule(dynamic, 128)
        for (int i = 1; i < num_vectors; ++i)
        {
            const float *query = &data_flat[i * dimension];
            int level = get_random_level();

            // 涓寸晫鍖猴細鏇存柊鏈€澶у眰绾?            // 涓烘€ц兘鑰冭檻锛屼笉鍔犻攣璇诲彇锛屽彧鏈夋洿鏂版椂鍔犻攣锛屾垨鍘熷瓙鎿嶄綔
            // 杩欓噷绠€鍗曞鐞嗭紝max_level 浠呯敱涓荤嚎绋嬫洿鏂板彲鑳戒笉瀹夊叏锛屼絾 HNSW 鍏佽杩欑 loose consistency
            // 鎴栬€呯敤 critical 鏇存柊 global max_level
            int cur_max_level = max_level;
            int curr_ep = enter_point;

            // 1. 璐┆鎼滅储鎵惧埌褰撳墠灞傜骇鐨勫叆鍙ｇ偣
            if (level < cur_max_level)
            {
                float min_dist = dist_l2_float_avx(query, &data_flat[curr_ep * dimension], dimension);
                for (int lc = cur_max_level; lc > level; --lc)
                {
                    bool changed = true;
                    while (changed)
                    {
                        changed = false;
                        const vector<int> &nbs = nodes[curr_ep].neighbors[lc]; // 璇绘搷浣滐紝鍙兘涓嶅畨鍏紵HNSW鏋勫缓閫氬父闇€瑕佺粏绮掑害閿?                        // 娉ㄦ剰锛氳繖閲岃鍙?neighbors 鏃跺彲鑳戒細鏈夊叾浠栫嚎绋嬪湪鍐欏叆銆?                        // 鏍囧噯鍋氭硶锛氬姞璇婚攣锛屾垨鑰呭埄鐢?vector 鐨勫悇灞傜嫭绔嬫€с€?                        // 鍦ㄦ湰鎸囧崡鐨勭畝鍗曞疄鐜颁腑锛屾垜浠帴鍙楄交寰殑鏁版嵁绔炰簤甯︽潵鐨勯闄╋紝鎴栬€呭湪鍐欏叆鏃?Copy-On-Write銆?                        // 瀹為檯涓婏紝涓轰簡涓ユ牸姝ｇ‘鎬э紝搴旇閿佷綇褰撳墠鑺傜偣璇诲彇銆?                        // 浣嗕负浜嗘€ц兘锛屽ぇ閮ㄥ垎寮€婧愬疄鐜?濡俬nswlib)閲囩敤浜嗕箰瑙傞攣鎴栫粏绮掑害閿併€?
                        // 绠€鍗曠増鏈細鍙湪杩炴帴鏃跺姞閿併€傛悳绱㈡椂涓嶅姞閿侊紙鍙兘璇诲埌鏃ф暟鎹級銆?                        for (int n : nbs)
                        {
                            float d = dist_l2_float_avx(query, &data_flat[n * dimension], dimension);
                            if (d < min_dist)
                            {
                                min_dist = d;
                                curr_ep = n;
                                changed = true;
                            }
                        }
                    }
                }
            }

            // 鍒濆鍖栧綋鍓嶈妭鐐?            // 鍙湁褰撳墠绾跨▼璁块棶 nodes[i]锛屾棤闇€閿?            nodes[i].neighbors.resize(level + 1);

            // 2. 浠?level 鍚戜笅鏋勫缓
            // 闇€瑕佸湪姣忓眰鎵惧埌 ef_construction 涓渶杩戦偦浣滀负鍊欓€?            vector<int> ep_container = {curr_ep};

            for (int lc = min(level, cur_max_level); lc >= 0; --lc)
            {
                vector<int> candidates;
                search_layer_build(query, candidates, ep_container, EF_CONSTRUCTION, lc);

                // RobustPrune 閫夐偦灞呴€昏緫
                // 闇€瑕侀噸鏂拌绠楄窛绂诲苟鎺掑簭
                vector<pair<float, int>> sorted_cand;
                for (int c : candidates)
                {
                    sorted_cand.push_back({dist_l2_float_avx(query, &data_flat[c * dimension], dimension), c});
                }
                sort(sorted_cand.begin(), sorted_cand.end());

                // 閫夋嫨閭诲眳
                vector<int> selected_neighbors;
                int M_limit = (lc == 0) ? M_max0 : M_max;

                // Robust Prune Implementation inside loop
                for (const auto &pair : sorted_cand)
                {
                    if (selected_neighbors.size() >= (size_t)M_limit)
                        break;
                    int cand_id = pair.second;
                    float dist_to_q = pair.first;

                    bool good = true;
                    for (int exist_id : selected_neighbors)
                    {
                        float dist_exist = dist_l2_float_avx(
                            &data_flat[cand_id * dimension],
                            &data_flat[exist_id * dimension],
                            dimension);
                        if (dist_exist * GAMMA < dist_to_q)
                        {
                            good = false;
                            break;
                        }
                    }
                    if (good)
                        selected_neighbors.push_back(cand_id);
                }

                // 鍙屽悜杩炴帴
                // 1. 灏?selected 杩炴帴鍒?i
                nodes[i].neighbors[lc] = selected_neighbors;

                // 2. 灏?i 杩炴帴鍒?selected 涓殑姣忎釜鑺傜偣 (闇€瑕佸姞閿?
                for (int neighbor_id : selected_neighbors)
                {
                    omp_set_lock(&node_locks[neighbor_id]);
                    vector<int> &target_neighbors = nodes[neighbor_id].neighbors[lc];

                    // 鍐嶆鎵ц RobustPrune 濡傛灉婊′簡
                    bool need_prune = false;
                    target_neighbors.push_back(i); // 鍏堝姞鍏?                    if (target_neighbors.size() > (size_t)M_limit)
                    {
                        need_prune = true;
                    }

                    if (need_prune)
                    {
                        // 閲嶆柊璁＄畻璇ラ偦灞呯殑鎵€鏈夎繛鎺ョ殑璺濈
                        vector<pair<float, int>> t_cand;
                        // 杩欓噷 query 鍙樻垚浜?data_flat[neighbor_id]
                        const float *target_vec = &data_flat[neighbor_id * dimension];
                        for (int tn : target_neighbors)
                        {
                            t_cand.push_back({dist_l2_float_avx(target_vec, &data_flat[tn * dimension], dimension), tn});
                        }
                        sort(t_cand.begin(), t_cand.end());

                        vector<int> new_conn;
                        for (const auto &pair : t_cand)
                        {
                            if (new_conn.size() >= (size_t)M_limit)
                                break;
                            int c_id = pair.second;
                            float d_q = pair.first;
                            bool good = true;
                            for (int ex : new_conn)
                            {
                                float d_ex = dist_l2_float_avx(
                                    &data_flat[c_id * dimension],
                                    &data_flat[ex * dimension],
                                    dimension);
                                if (d_ex * GAMMA < d_q)
                                {
                                    good = false;
                                    break;
                                }
                            }
                            if (good)
                                new_conn.push_back(c_id);
                        }
                        target_neighbors = new_conn;
                    }

                    omp_unset_lock(&node_locks[neighbor_id]);
                }

                ep_container = selected_neighbors; // 涓嬩竴灞傜殑鍏ュ彛
            }

            // 鏇存柊鍏ㄥ眬鍏ュ彛鐐?(濡傛灉鏄洿楂樺眰)
            if (level > max_level)
            {
#pragma omp critical
                {
                    if (level > max_level)
                    {
                        max_level = level;
                        enter_point = i;
                    }
                }
            }
        }
    }

    // 娓呯悊閿?    for (int i = 0; i < num_vectors; ++i)
        omp_destroy_lock(&node_locks[i]);

    // 鏋勫缓鍚庝紭鍖栵細Layer 0 鎵佸钩鍖?    flatten_layer0();

    // 鏋勫缓鍚庝紭鍖栵細鏍囬噺閲忓寲 (SQ)
    init_quantization();
}

void Solution::flatten_layer0()
{
    // 璁＄畻鎵佸钩鍖栨墍闇€绌洪棿
    size_t total_size = 0;
    final_graph_offsets.resize(num_vectors);

    for (int i = 0; i < num_vectors; ++i)
    {
        final_graph_offsets[i] = total_size;
        // 鏍煎紡: [count, n1, n2, ...]
        if (nodes[i].neighbors.size() > 0)
        {
            total_size += 1 + nodes[i].neighbors[0].size();
        }
        else
        {
            total_size += 1; // count = 0
        }
    }

    final_graph_flat.resize(total_size);

// 濉厖鏁版嵁
#pragma omp parallel for
    for (int i = 0; i < num_vectors; ++i)
    {
        size_t offset = final_graph_offsets[i];
        if (nodes[i].neighbors.size() > 0)
        {
            const vector<int> &nbs = nodes[i].neighbors[0];
            final_graph_flat[offset] = (int)nbs.size();
            memcpy(&final_graph_flat[offset + 1], nbs.data(), nbs.size() * sizeof(int));

            // 閲婃斁鍐呭瓨锛歀ayer 0 鏁版嵁宸茶浆绉伙紝娓呯┖鍘?vector
            // vector<int>().swap(nodes[i].neighbors[0]);
            // 娉ㄦ剰锛氫笉瑕佸湪杩欓噷閲婃斁锛屽洜涓?high layer search 鍙兘鍋跺皵闇€瑕佺敤鍒帮紵
            // 涓嶏紝high layer search 鍙秹鍙?lc > 0銆?            // 瀹為檯涓婏紝涓轰簡鍐呭瓨锛屾垜浠彲浠ユ竻绌?nodes[i].neighbors[0]
            // 浣?nodes 鏄?vector<vector<int>>锛屾竻绌虹0涓厓绱犲彧鏄彉涓虹┖ vector
        }
        else
        {
            final_graph_flat[offset] = 0;
        }
    }
}

// --- 鎼滅储鎺ュ彛 ---
void Solution::search(const vector<float> &query, int *res)
{
    if (num_vectors == 0)
        return;

    // 1. 閲忓寲鏌ヨ鍚戦噺 (鐢ㄤ簬Layer 0)
    tls_quant_query_buf.resize(dimension);
    unsigned char *q_quant_ptr = tls_quant_query_buf.data();
    quantize_vec(query.data(), q_quant_ptr);

    int curr_ep = enter_point;
    vector<int> ep_container = {curr_ep};

    // 2. 楂樺眰瀵艰埅 (Layer max ~ 1) - 浣跨敤绮剧‘璺濈 (Float + AVX)
    // 浼樺寲鏂规D寤鸿锛氶珮灞俥f鍙涓?鎴栫◢澶с€備负浜嗗彫鍥炵巼锛屼繚鎸?ef=1 瓒冲锛?    // 浣嗗鏋滃湪 layer 1 闄勮繎锛屽彲浠ョ◢寰澶ф悳绱㈣寖鍥淬€?    // 鍩哄噯浠ｇ爜閫氬父 ef=1銆?
    for (int lc = max_level; lc > 0; --lc)
    {
        // 鍦ㄩ珮灞傛垜浠笉鍋氬鏉傜殑鎼滅储锛屽彧鍋氳椽濠笅闄?        // 浣嗗鐢?search_layer_query 涔熷彲浠ワ紝鍙 ef=1
        // 涓轰簡鏋佽嚧閫熷害锛屾墜鍐欑畝鍗曡椽濠亶鍘?        bool changed = true;
        while (changed)
        {
            changed = false;
            float dist = dist_l2_float_avx(query.data(), &data_flat[curr_ep * dimension], dimension);
            const vector<int> &nbs = nodes[curr_ep].neighbors[lc];

            for (int n : nbs)
            {
                float d = dist_l2_float_avx(query.data(), &data_flat[n * dimension], dimension);
                if (d < dist)
                {
                    dist = d;
                    curr_ep = n;
                    changed = true;
                }
            }
        }
    }
    ep_container[0] = curr_ep;

    // 3. 搴曞眰鎼滅储 (Layer 0) - 浣跨敤鎵佸钩鍥?    vector<int> candidates;
    search_layer_query(query.data(), q_quant_ptr, candidates, ep_container, EF_SEARCH, 0);

    // 4. 濉厖缁撴灉
    // [閲嶈] search_layer_query 浠庢渶澶у爢 W pop 鍑烘潵鐨勯『搴忔槸璺濈浠庤繙鍒拌繎锛堝€掑簭锛?    // 闇€瑕佸弽杞墠鑳藉緱鍒版渶杩戠殑10涓?    std::reverse(candidates.begin(), candidates.end());

    for (int i = 0; i < 10 && i < (int)candidates.size(); ++i)
    {
        res[i] = candidates[i];
    }
    // 濡傛灉涓嶈冻10涓紝琛ヤ綅
    for (int i = candidates.size(); i < 10; ++i)
    {
        res[i] = candidates.empty() ? 0 : candidates[0];
    }
}

// [璋冭瘯鍔熻兘] 鏆村姏鎼滅储 - 鐢ㄤ簬楠岃瘉HNSW缁撴灉鐨勬纭€?#ifdef DEBUG_BRUTE_FORCE
void Solution::search_brute_force(const vector<float> &query, int *res) const
{
    if (num_vectors == 0)
        return;

    // 璁＄畻鎵€鏈夌偣鐨勮窛绂?    vector<pair<float, int>> all_dists;
    all_dists.reserve(num_vectors);

    for (int i = 0; i < num_vectors; ++i)
    {
        float d = dist_l2_float_avx(query.data(), &data_flat[i * dimension], dimension);
        all_dists.push_back({d, i});
    }

    // 鎺掑簭
    sort(all_dists.begin(), all_dists.end());

    // 鍙栧墠10涓?    for (int i = 0; i < 10 && i < (int)all_dists.size(); ++i)
    {
        res[i] = all_dists[i].second;
    }
    for (int i = all_dists.size(); i < 10; ++i)
    {
        res[i] = all_dists.empty() ? 0 : all_dists[0].second;
    }
}
#endif
